1. install python 
    - while installing make sure to select "add to path" option
2. press windows + R
3. type cmd , press enter
4. run command in cmd python -m pip install -r requirements.txt
5. go to folder
6. press shift + right click
7. open in terminal
8. run python app.py
9. open browser and open "http://localhost:3000/"
10. To see feedbacks open "http://localhost:3000/view_feedback"
 -username : patel password : patel 